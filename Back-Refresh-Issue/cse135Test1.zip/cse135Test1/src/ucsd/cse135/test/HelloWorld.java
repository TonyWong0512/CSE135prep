package ucsd.cse135.test;

//Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

//Extend HttpServlet class
public class HelloWorld extends HttpServlet {

public void init() throws ServletException
{
	super.init();
}

public void doPost(HttpServletRequest request,
                 HttpServletResponse response)
         throws ServletException, IOException
{
/*Code which on refresh gives POST notification{*/	
//	  response.setContentType("text/html");
//	  PrintWriter out = response.getWriter();
//	  out.println("<h1>" + "Hello " + request.getParameter("p") + "</h1>");
/*}*/
	/*Code which on refresh doesn't give POST notification{*/
	  request.getSession().setAttribute("name", request.getParameter("p"));
      response.sendRedirect("/cse135Test1/next.jsp");
    /*}*/
}
public void doGet(HttpServletRequest request,
        HttpServletResponse response)
throws ServletException, IOException
{
	doPost(request, response);
}

public void destroy()
{
   // do nothing.
}
}
